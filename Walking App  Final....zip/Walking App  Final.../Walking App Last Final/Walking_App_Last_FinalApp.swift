//
//  Walking_App_Last_FinalApp.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import SwiftUI

@main
struct Walking_App_Last_FinalApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            SplashScreenView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
