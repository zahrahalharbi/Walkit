//
//  Step.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import Foundation

struct Step: Identifiable {
    
    let id = UUID()
    let count: Int
    let date: Date
    
}
