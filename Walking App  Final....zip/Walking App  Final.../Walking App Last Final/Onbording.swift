//
//  Onbording.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import Foundation
import SwiftUI


struct Onboarding : View {
    @State private var pageIndex = 0
    private let pages: [Page] = Page.samplePages
    @State var  isshown = false
    private let dotAppearance = UIPageControl.appearance()
    
    var body: some View {
            TabView(selection: $pageIndex) {
                ForEach(pages) { page in
                    VStack {
                        PageView(page: page)
                        
                        if page == pages.last {
                            Button{isshown.toggle()}
                        label: { Text(" get started  ")
                                .frame(width: 150, height: 30)
                                .fontWeight(.medium)}
                                .buttonStyle(.bordered)
                                .foregroundColor(.white)
                                .background(Color("Color"))
                                .fullScreenCover(isPresented: $isshown){Indivisual()}
                                .cornerRadius(8)
                                .offset(x:0,y:-15)
                        }
                        
                        Spacer()
                    }
                    .tag(page.tag)
                }
            }
            .ignoresSafeArea()
            .animation(.easeInOut, value: pageIndex)// 2
            .indexViewStyle(.page(backgroundDisplayMode: .interactive))
            .tabViewStyle(PageTabViewStyle())
            
            .onAppear {
                dotAppearance.currentPageIndicatorTintColor = .black
                dotAppearance.pageIndicatorTintColor = .gray
            }
        }
        func incrementPage() {
            pageIndex += 1
        }
        
        func goToZero() {
        }
   
    }
struct Onboarding_Previews: PreviewProvider {
    static var previews: some View {
        Onboarding()
    }
}
