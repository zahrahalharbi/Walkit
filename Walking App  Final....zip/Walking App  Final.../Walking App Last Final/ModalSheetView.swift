//
//  SheetView.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//
import SwiftUI

struct ModalSheetView: View {
    
    @Binding var place: String
    @Binding var show: Bool
    
    var body: some View {
        VStack {
//            Button(action: {
//                withAnimation(.spring()){
//                    show.toggle()
//                }
//            }){
//                Image(systemName: "xmark")
//                    .font(Font.title.weight(.bold))
//                    .foregroundColor(.black)
//            }
            
        //    Spacer()
            

            Spacer()
            
            VStack(alignment: .center, spacing: 10)
            {
                HStack(alignment: .center){
                    Text(details[place]?.title ?? "")
                        .foregroundColor(Color ("Color"))
                        .fontWeight(.semibold)
                        .font(.system(size: 25))
//                        .padding(.top,-150)
//                        .padding(.leading,50)
                       // .lineLimit(6)
                        .padding(.top,-50)
                        .padding(.leading,60)
                       
                    
                    Spacer()
                }

                
                Text(details[place]?.description ?? "")
                    .foregroundColor(.black)
                    .lineLimit(3)
                    .padding(.top,-20)
                    .padding(.leading,20)

//
            }
            .padding(.bottom , 20)
        }.imageScale(.medium)
      //  .padding(.top, UIApplication.shared.windows.first?.safeAreaInsets.top)
        .background(
            Image(place)
                .resizable()
                .scaledToFill()
                .frame(width: 300,height: 200)
                .edgesIgnoringSafeArea(.all)
               // .cornerRadius(5)
                .clipShape(RoundedRectangle(cornerRadius: 10))
        )
        
    }
}

struct Details: Identifiable {
    var id = UUID()
    var title: String
    var description: String
}

var details = [

  
    "spotify" : Details(title: "Spotify Premium 30 Days", description: "walk for 7 days consecutive"),
    "xbox" : Details(title: "        Xbox Gift Card 5$ ", description: " 20 minute walk for 4 days consecutive"),
    "ps" : Details(title: "Playstation Gift Card 5$", description: "60 minute walk for 4 days consecutive")

]



