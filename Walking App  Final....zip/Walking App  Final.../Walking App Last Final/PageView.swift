//
//  PageView.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import Foundation
import SwiftUI


struct PageView: View {
    
    var page: Page
    
    var body: some View {
        VStack(spacing: 10) {
            Image("\(page.imageUrl)")
                .resizable()
                .edgesIgnoringSafeArea(.top)
                .scaledToFill()
                .cornerRadius(20)
                .frame(width: 440,height: 619)
                //.cornerRadius(1)
            Spacer()
            VStack(spacing: 10){
                Text(page.description)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .font(Font.custom("SF Compact", size: 25))
                    .multilineTextAlignment(.center)
                    .lineLimit(nil)
                    .padding(.top, 20)
                   // .frame(width:300,height: 400)
            }
            Spacer()
        }.ignoresSafeArea()
    }
}
struct PageView_Previews: PreviewProvider {
    static var previews: some View {
        PageView(page: .init(name: "", description: "This is a sample description for the purpose of debugging", imageUrl: "walk1", tag: 0))
    }
}
