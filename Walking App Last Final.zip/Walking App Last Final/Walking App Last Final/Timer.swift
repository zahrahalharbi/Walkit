//
//  Timer.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import SwiftUI
import HealthKit
import Foundation
struct Timer: View {
    private var healthStore: Healthstore?
    @State var steps: [Step] = [Step]()
    @State var  steps_left = """
   3000
Steps left
"""
    @State var  press = false
    @State var progress : Double = 0.2
    
    init() { healthStore = Healthstore()}
    var body : some View {
        ZStack{
            Text("10000")
                .padding(.top,-100)
                .font(.system(size: 15))
                .fontWeight(.semibold)
            
            Circle()
                .offset(x:100 , y:310)
            
                .size(width: 194, height: 195)
                .foregroundColor(Color(red: 0.85 , green: 0.835 , blue: 0.835))
            Circle()
                .offset(x:-27 , y:0)
                .trim(from: 0.00, to: 1.00)
                .stroke(style: StrokeStyle(lineWidth: 4.0, lineCap: .round, lineJoin: .round))
                .frame(width: 231, height: 215)
                .rotationEffect(Angle(degrees: -90))
            
                .onAppear(perform: {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2 ){
                        
                    } })
            
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
            
            
            Text("\(steps.count)")
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                .padding(.top,50)
            
                .fontWeight(.semibold)
                .font(.system(size: 35))
            Circle()
                .size(width: 56, height: 53)
                .foregroundColor(Color(red: 0.78, green: 0.174, blue: 0.172))
                .offset(x:70 , y:450)
            Text(steps_left)
                .fontWeight(.semibold)
                .font(.system(size: 9))
                .foregroundColor(.white)
                .offset(x:-98 , y:97)
            
            
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
            Text("1/3")
                .offset(x:0 , y:150)
                .font(.system(size: 15))
                .fontWeight(.semibold)
        }
    }
    
}

struct Timer_Previews: PreviewProvider {
    static var previews: some View {
        Timer()
    }
}
