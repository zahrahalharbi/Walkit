//
//  PageView.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import Foundation
import SwiftUI


struct PageView: View {
    
    var page: Page
    
    var body: some View {
        VStack(spacing: 20) {
            Image("\(page.imageUrl)")
                .resizable()
                .edgesIgnoringSafeArea(.top)
                .scaledToFit()
                .cornerRadius(1)
                .cornerRadius(1)
            //Spacer()
            Text(page.description)
                .font(.title2)
                .fontWeight(.bold)
                .font(Font.custom("SF Compact", size: 25))
                .multilineTextAlignment(.center)
                .lineLimit(nil)
                .padding(.top, 29.0)
                .frame(width:300)
                
            Spacer()
        }.ignoresSafeArea()
    }
}
struct PageView_Previews: PreviewProvider {
    static var previews: some View {
        PageView(page: .init(name: "", description: "This is a sample description for the purpose of debugging", imageUrl: "walk1", tag: 0))
    }
}
