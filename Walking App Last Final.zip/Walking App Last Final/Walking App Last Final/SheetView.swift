//
//  SheetView.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import SwiftUI


struct ModalSheetView: View {
    
    @Binding var place: String
    @Binding var show: Bool
    
    var body: some View {
        VStack {
            
            Text("Spotify Premium 30 Days")
                .font(Font.custom("SF Compact", size: 26))
                .foregroundColor(Color ("Color1"))
                .fontWeight(.semibold)
            
            
            Image("spotify1")
                .resizable()
                .cornerRadius(10)
                .frame(width: 250, height: 130)
            
            Text("10000 Steps each day for a week")
                .font(Font.custom("SF Compact", size: 15))
                .foregroundColor(.black)
            
            
            Button(action: {
                share()
            }) {
                Text("invite Friends")
                    .foregroundColor(.white)
                    .fontWeight(.bold)
                    .padding(.vertical,10)
                    .padding(.horizontal,75)
                    .background(Color ("Color"))
                    .clipShape(Capsule())
            }
            
            
            
            
            
            
            
        }
        
        
        
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.white)
        
        
    }
}


struct Details: Identifiable {
    var id = UUID()
    var title: String
    var description: String
}

var details = [

    "JAPAN" : Details(title: "Tokyo Trip", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae aliquam magna, in ultricies justo. Duis eget tempor lorem. Ut pretium velit sed nisi luctus, vitae mollis odio viverra. Aenean et tempor diam. Aliquam erat volutpat"),
    "MALDIVES" : Details(title: "FUVAHMULAH Trip", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae aliquam magna, in ultricies justo. Duis eget tempor lorem. Ut pretium velit sed nisi luctus, vitae mollis odio viverra. Aenean et tempor diam. Aliquam erat volutpat")

]



func share() {
    guard let urlShare = URL(string: "https://developer.apple.com/xcode/swiftui/") else { return }
    let activityVC = UIActivityViewController(activityItems: [urlShare], applicationActivities: nil)
       UIApplication.shared.windows.first?.rootViewController?.present(activityVC, animated: true, completion: nil)
}
