//
//  healthInfos.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 16/05/1444 AH.
//

import SwiftUI

struct healthInfos: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct healthInfos_Previews: PreviewProvider {
    static var previews: some View {
        healthInfos()
    }
}
