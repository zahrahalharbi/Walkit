//
//  Step.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 20/05/1444 AH.
//

import Foundation

struct Step: Identifiable {
    let id = UUID()
    let count: Int
    let date: Date
}
