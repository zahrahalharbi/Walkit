//
//  StepCounterApp.swift
//  StepCounter
//
//  Created by Anik on 13/8/20.
//

import SwiftUI

@main
struct StepCounterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
