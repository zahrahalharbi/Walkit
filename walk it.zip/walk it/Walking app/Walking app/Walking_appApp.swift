//
//  Walking_appApp.swift
//  Walking app
//
//  Created by Zahrah. on 06/12/2022.
//

import SwiftUI

@main
struct SplashScreenApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
        
    }
}

