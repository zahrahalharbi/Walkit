//
//  ContentView1.swift
//  Walking app
//
//  Created by Zahrah. on 06/12/2022.
//

import SwiftUI


struct PageView: View {
    
    var page: Page
    
    var body: some View {
        VStack(spacing: 20) {
            Image("\(page.imageUrl)")
                .resizable()
                .edgesIgnoringSafeArea(.top)
                .scaledToFit()
                .cornerRadius(1)
                .cornerRadius(1)
            Spacer()
            Text(page.name)
                .font(.title)
                .font(Font.custom("Baskerville-Bold", size: 9))
                .foregroundColor(.black.opacity(0.80))
            Text(page.description)
                .fontWeight(.bold)
                .font(Font.custom("SF Compact", size: 18))
                .frame(width:300)
            Spacer()
        }.ignoresSafeArea()
    }
}
struct PageView_Previews: PreviewProvider {
    static var previews: some View {
        PageView(page: .init(name: "Title Example", description: "This is a sample description for the purpose of debugging", imageUrl: "walk1", tag: 0))
    }
}
