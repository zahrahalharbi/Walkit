//
//  appmathamtics.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 22/05/1444 AH.
//

import Foundation
 
//class counting {
//    var progresscircle  = 0.0
//    var progress: Array<Int> = Array()
//    
//    switch progress.count{
//    case 1000:
//        progresscircle  = 0.1
//        
//    default:
//        <#code#>
//    }}
////func calculating(progress : [Int] , progresscircle : Double ){
//   // while progress.count <= 10000 {
//      //  progresscircle = +0.5
//   // }
////}
////while progress <= 10000 {
//  //  progresscircle  += 0.5
//}

