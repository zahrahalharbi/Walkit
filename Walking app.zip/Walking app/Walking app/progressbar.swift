//
//  progressbar.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 17/05/1444 AH.
//

import SwiftUI

struct progressbar: View {
    var width1 : CGFloat = 177
    var hight1 : CGFloat = 15
    var percent : CGFloat = 77
    var body: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 15.0)
                .frame(width: width1 , height: hight1 )
            .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
            RoundedRectangle(cornerRadius: hight1 )
                .frame(width:percent , height:hight1)
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
        }
        
    }
}

struct progressbar_Previews: PreviewProvider {
    static var previews: some View {
        progressbar()
    }
}
