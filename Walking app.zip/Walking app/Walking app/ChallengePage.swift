//
//  ChallengePage.swift
//  Walking app
//
//  Created by Zahrah. on 18/12/2022.
//

import Foundation
import SwiftUI

struct ChallengePage: View {
    @State var spotfiyView = false
    @State var ecsapeView = false
    var body: some View {
        ZStack{
            
                Text("Explore Challenges ")
                    .font(Font.custom("SF Compact", size: 28))
                    .fontWeight(.semibold)
                    .offset(x:0,y:-350)
            
                Text("Individual Challenges")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(Font.custom("SF Compact", size: 26))
                    .foregroundColor(Color ("CusColor"))
                    .fontWeight(.semibold)
                    .padding(.leading,20)
                    .padding(.top,-300)
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: -10) {
                    
                    Button(action: {
                        withAnimation{
                            spotfiyView.toggle()
                        }
                    })
                      {
                          VStack{ Image("spotify")
                                  .resizable()
                                  .cornerRadius(10)
                                 // .border(.black)
                              Divider()
                              Text("Spotify")
                                  .font(Font.custom("SF Compact", size: 15))
                                  .foregroundColor(Color ("Color"))
                                  .fontWeight(.semibold)
                              Text(" Premium 30 Days")
                                  .font(Font.custom("SF Compact", size: 15))
                                  .foregroundColor(.black)
                                  .fontWeight(.semibold)
                                  .padding(.bottom,5)
                          }
                    }
                      .frame(width: 170, height: 190)
                      .background(Color.white)
                      .cornerRadius(10)
                      .overlay(RoundedRectangle(cornerRadius: 10)
                      .stroke(Color.black, lineWidth: 0.2))
                      .shadow(radius: 3)
                      .padding()
                  //  Spacer()
                    
                    VStack{
                        Image("play")
                            .resizable()
                            .cornerRadius(10)
                        Divider()
                        VStack(){
                            Text("Playstation")
                                .font(Font.custom("SF Compact", size: 15))
                                .foregroundColor(Color ("Color"))
                                .fontWeight(.semibold)
                            Text("Gift Card 5$")
                                .font(Font.custom("SF Compact", size: 15))
                                .foregroundColor(.black)
                                .fontWeight(.semibold)
                                .padding(.bottom,5)
                        }
                    }
                    .frame(width: 170, height: 190)
                    .background(Color.white)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 0.2))
                    .shadow(radius: 3)
                    .padding()
                  //  Spacer()
                   
                    VStack{
                        Image("xbox1")
                            .resizable()
                            .cornerRadius(10)
                        Divider()
                      VStack(){
                            Text("Xbox")
                                .font(Font.custom("SF Compact", size: 15))
                                .foregroundColor(Color ("Color"))
                                .fontWeight(.semibold)
                            Text("Gift Card 5$")
                                .font(Font.custom("SF Compact", size: 15))
                                .foregroundColor(.black)
                                .fontWeight(.semibold)
                                .padding(.bottom,5)
                        }
                    }
                    .frame(width: 170, height: 190)
                    .background(Color.white)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 0.2))
                    .shadow(radius: 3)
                    .padding()
                }.padding(.bottom,300)
            }
            
            HStack{
                Text("Group Challenges")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(Font.custom("SF Compact", size: 26))
                    .foregroundColor(Color ("CusColor"))
                      .fontWeight(.semibold)
                      .padding(.leading,20)
                      .padding(.bottom)
            }
            ZStack{
                Button(action: {
                    withAnimation{
                        ecsapeView.toggle()
                    }
                }) {
                    Image("escape")
                        .resizable()
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                    //.shadow(radius: 5)
                        .frame(width: 100, height: 105)
                        .padding(.leading)
                    //   .padding(.top,200)
                    
                    VStack{
                        
                        Text("5 Tickets to Escape the room ")
                            .font(Font.custom("SF Compact", size: 17))
                            .foregroundColor(Color ("Color"))
                        //  .padding(.leading,100)
                        //   .padding(.top,210)
                        
                        Text("Each competitive has to walk\nfor 20 min each day for a week ")
                            .font(Font.custom("SF Compact", size: 17))
                            .foregroundColor(.black)
                        //   .padding(.leading,135)
                        //  .padding(.top,1)
                            .offset(x:1,y:3)
                        HStack{
                            Image(systemName: "person.fill")
                                .foregroundColor(Color ("Color"))
                            Text("4-5")
                                .font(Font.custom("SF Compact", size: 13))
                                .foregroundColor(Color ("Color"))
                            Image(systemName: "location.circle.fill")
                                .foregroundColor(Color ("Color"))
                            Text("Riyadh")
                                .font(Font.custom("SF Compact", size: 13))
                                .foregroundColor(Color ("Color"))
                        }.padding(.top,1).padding(.leading,110)
                    }
                }
            }   .frame(width: 370, height: 150)
                .background(Color.white)
                .cornerRadius(10)
                .overlay(RoundedRectangle(cornerRadius: 10)
                .stroke(Color.black, lineWidth: 0.2))
                .shadow(radius: 3)
                .padding(.top,220)
            
            ZStack{
              
                    HStack{
                        Image("winter")
                            .resizable()
                            .clipShape(RoundedRectangle(cornerRadius: 5))
                        //.shadow(radius: 5)
                            .frame(width: 100, height: 105)
                            .padding(.trailing,230)
                         //   .padding(.top,500)
                    }
                VStack{
                        Text("5 Tickets to winter wonderland  ")
                            .font(Font.custom("SF Compact", size: 17))
                            .foregroundColor(Color ("Color"))
                            .padding(.leading,130)
                          //  .padding(.top,500)
                            
                        Text("Each competitive has to walk for 40 min each day for a week ")
                            .font(Font.custom("SF Compact", size: 17))
                            .foregroundColor(.black)
                            .padding(.leading,130)
                            .offset(x:0,y:3)
                          //  .padding(.top,1)
                        HStack{
                            Image(systemName: "person.fill")
                                .foregroundColor(Color ("Color"))
                            Text("3-5")
                                .font(Font.custom("SF Compact", size: 13))
                                .foregroundColor(Color ("Color"))
                            Image(systemName: "location.circle.fill")
                                .foregroundColor(Color ("Color"))
                            Text("Riyadh")
                                .font(Font.custom("SF Compact", size: 13))
                                .foregroundColor(Color ("Color"))
                        }.padding(.top,1).padding(.leading,230)
                    }
                
            }.frame(width: 370, height: 150)
                .background(Color.white)
                .cornerRadius(10)
                .overlay(RoundedRectangle(cornerRadius: 10)
                .stroke(Color.black, lineWidth: 0.2))
                .shadow(radius: 3)
                .padding(.top,550)
             
            if spotfiyView{
               AnotherView(show: $spotfiyView)
            }
            if ecsapeView{
                AnotherView1(show: $ecsapeView)
            }
        }//end of the first Z stack
    }//end of the body
}//end of the struct

struct AnotherView : View {
    @Binding var show : Bool
        var body: some View {
            ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)){
                VStack(spacing: 25){
                    
                    Text("Spotify Premium 30 Days")
                        .font(Font.custom("SF Compact", size: 26))
                        .foregroundColor(Color ("CusColor"))
                        .fontWeight(.semibold)
                       // .padding(.bottom,230)

                    Image("spotify1")
                        .resizable()
                        .cornerRadius(10)
                        .frame(width: 250, height: 130)

                    Text("20 minute walk for 4 days consecutive")
                        .font(Font.custom("SF Compact", size: 15))
                        .foregroundColor(.black)
                       // .fontWeight(.semibold)
                      // .padding(.top,200)
                    
                    Button(action:{
                        withAnimation{
                            show.toggle()
                        }
                    }){
                        
                        Text("Cancle")
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            .padding(.vertical,10)
                            .padding(.horizontal,75)
                            .background(Color ("Color"))
                            .clipShape(Capsule())
                        
                    }
                }
                .padding(.vertical,25)
                .padding(.horizontal,30)
                .background(.white)
                .cornerRadius(25)
        
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.primary.opacity(0.35)
               
            )
        }
    }
    
struct AnotherView1 : View {
    @Binding var show : Bool
    var body: some View {
        
        
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)){
            VStack(spacing: 10){
                
                
                Image("escape")
                    .resizable()
                    .cornerRadius(10)
                    .frame(width: 350, height: 240)
                // .padding(.bottom,140)
                Text("5 Tickets to Escape the room")
                    .font(Font.custom("SF Compact", size: 26))
                    .foregroundColor(Color ("Color"))
                    .fontWeight(.semibold)
                // .padding(.top,170)
                
                Text("Each competitive has to walk for 20 min each\nday for a week")
                    .font(Font.custom("SF Compact", size: 15))
                    .foregroundColor(.black)
                    .fontWeight(.semibold)
                // .padding(.top,250)
                VStack{
                    HStack{
                        Image(systemName: "location.circle.fill")
                            .foregroundColor(Color ("Color"))
                        Text("Riyadh")
                            .font(Font.custom("SF Compact", size: 13))
                            .foregroundColor(Color ("Color"))
                        
                    } //.offset(x:5,y:1)
                    
                    HStack{
                        Image(systemName: "person.fill")
                            .foregroundColor(Color ("Color"))
                        Text("3-5")
                            .font(Font.custom("SF Compact", size: 13))
                            .foregroundColor(Color ("Color"))
                    }.offset(x:-10,y:0)
                }.padding(.leading)
                //.padding(.trailing,25)
                .offset(x:-130,y:0)
                
                
                Button(action:{
                    withAnimation{
                        show.toggle()// here invite friend page
                    }
                }){
                    
                    Text("Invite Friend")
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .padding(.vertical,7)
                        .padding(.horizontal,25)
                        .background(Color ("Color"))
                        .clipShape(Capsule())
                    
                }.padding(.leading,180)
            }
            .padding(.vertical,50)
            .padding(.horizontal,30)
            .background(.white)
            .cornerRadius(25)
            
            Button(action:{
                withAnimation{
                    show.toggle()
                }
            })
            {
                Image(systemName: "xmark.circle")
                    .font(.system(size: 28,weight: .bold))
                    .foregroundColor(Color ("Color"))
            }.padding(.top)
               .padding(.trailing)
              
        }  .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.primary.opacity(0.35))
        
    }}

    struct ChallengePage_Previews: PreviewProvider {
        static var previews: some View {
            ChallengePage()
        }
    }
    
