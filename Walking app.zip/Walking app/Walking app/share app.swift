//
//  share app.swift
//  Walking app
//
//  Created by Zahrah. on 18/12/2022.
//

import Foundation
import SwiftUI
 
struct ShareApp: View {
     
    var body: some View {
        VStack(spacing: 15){
             
            HStack(spacing: 15){
                 
                Button(action: {
 
                }) {
                    Image(systemName: "arrow.left").foregroundColor(Color.white)
                }
                 
                Spacer()
                 
                Button(action: {
                    share()
                }) {
                  
                }
                 
                Button(action: {
                     
                }) {
                    Image(systemName: "info.circle").foregroundColor(Color.white)
                }
                 
            }.padding()
             
            ZStack{
                Image("detail").resizable()
            }.frame(height: UIScreen.main.bounds.height / 2)
            .navigationBarTitle("")
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
             
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 15){
                    HStack{
                        Text("Details")
                    }
                }
                 
            }.padding(.top, 15)
            .padding(.horizontal, 15)
            Spacer()
             
        }.preferredColorScheme(.dark)
    }
     
    func share() {
        guard let urlShare = URL(string: "https://developer.apple.com/xcode/swiftui/") else { return }
        let activityVC = UIActivityViewController(activityItems: [urlShare], applicationActivities: nil)
           UIApplication.shared.windows.first?.rootViewController?.present(activityVC, animated: true, completion: nil)
    }
}
 
struct ShareApp_Previews: PreviewProvider {
    static var previews: some View {
        ShareApp()
    }
}
