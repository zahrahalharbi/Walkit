//
//  groupchallange2.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 19/05/1444 AH.
//

import SwiftUI

struct groupchallange2: View {
    var greetings = """
Welcome,
Mohammed 👋
"""
  //  @State var  progresscircle = 0.7
   @State var  steps_left = """
   3000
Steps left
"""
    @State var  press = false
    @State private var progress = 7000
    
   
        
    
    private var healthstore : Healthstore?
    init(){
        healthstore = Healthstore()
        
    }
    @State var  percent : CGFloat = 77
    var body: some View {
        VStack{
            Text(greetings)
                .fontWeight(.semibold)
                .padding(.leading,-150)
                .frame(width: 257.0, height: 68.0)
                .font(.system(size: 28))
            
            HStack{
                Button {
                    press.toggle()
                } label: {
                    Text("Individual ")
                        .foregroundColor(.black)
                        .frame(width: 166.0, height: 38.0)
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
                        .cornerRadius(8)
                        .font(.system(size: 15))
                    
                    
                }
                Button {
                    press.toggle()
                } label: {
                    Text("Group")
                        .foregroundColor(.white)
                        .frame(width: 166.0, height: 38.0)
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                        
                        .cornerRadius(8)
                        .font(.system(size: 15))
                    
                }
                
            }
            
            Text("10000")
                .offset(x:0 , y:90)
                .font(.system(size: 15))
                .fontWeight(.semibold)
            
            
            ZStack{
                Circle()
                    .offset(x:100 , y:100)
                
                    .size(width: 194, height: 195)
                    
                
                
                
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
               
             
                   
                 
                    
               
                Circle()
                    .offset(x:-30 , y:2)
                    .trim(from: 0.0, to: (Double(progress))/10000)
                    .stroke(style: StrokeStyle(lineWidth: 4.0, lineCap: .round, lineJoin: .round))
                    .frame(width: 231, height: 227)
                      .rotationEffect(Angle(degrees: -90))
                      
                
                
                   .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                Text("7000 Steps")
                    
                    .padding(.bottom,-100)
                    .fontWeight(.semibold)
                    .font(.system(size: 35))
                Circle()
                    .size(width: 56, height: 53)
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                    .offset(x:235 , y:270)
                Text(steps_left)
                    
                    .fontWeight(.semibold)
                  
                    .font(.system(size: 9))
                    .foregroundColor(.white)
                    .offset(x:67 , y:130)
                    
        
               
            }
            .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
            Text("1/3")
                .offset(x:0 , y:-20)
                .font(.system(size: 15))
                .fontWeight(.semibold)
            
            Text("Keep up the good work!")
                .offset(x:0 , y:-10)
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                .font(.system(size: 28))
                .fontWeight(.semibold)
            
            
            ZStack {
                RoundedRectangle(cornerRadius: 22)
                    .frame(width: 361, height: 197)
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.984, green: 0.984, blue: 0.984)/*@END_MENU_TOKEN@*/)
                    .shadow(radius: 3 , y: 2)
                    
                VStack{
                    Text("Group challenge status ")
                        .padding(.trailing,130)
                       
                        .font(.system(size: 15))
                        .fontWeight(.medium)
                        .foregroundColor(.black)
                HStack (spacing: 20){
                   
                    Text("You:")
                        .font(.system(size: 15))
                        .fontWeight(.regular)
                        .foregroundColor(.black)
                        
                    progressbar(width1: 177, hight1: 17 , percent: 77)
                    Text("\(Int(percent)) %")
                        .font(.system(size: 15))
                        .fontWeight(.regular)
                        .foregroundColor(.black)
                    
                }.padding(.trailing)
                    HStack (spacing: 20){
                       
                        Text("Ahmad:")
                            .font(.system(size: 15))
                            .fontWeight(.regular)
                            .foregroundColor(.black)
                            
                        progressbar(width1: 177, hight1: 17 , percent: 77)
                        Text("\(Int(percent)) %")
                            .font(.system(size: 15))
                            .fontWeight(.regular)
                            .foregroundColor(.black)
                        
                    }.padding(.trailing)
               
                 
                    HStack (spacing: 20){
                       
                        Text("Saleh:")
                            .font(.system(size: 15))
                            .fontWeight(.regular)
                            .foregroundColor(.black)
                            
                        progressbar(width1: 177, hight1: 17 , percent: 77)
                        Text("\(Int(percent)) %")
                            .font(.system(size: 15))
                            .fontWeight(.regular)
                            .foregroundColor(.black)
                        
                    }.padding(.trailing)
                    HStack (spacing: 20){
                       
                        Text("Waleed:")
                            .font(.system(size: 15))
                            .fontWeight(.regular)
                            .foregroundColor(.black)
                            
                        progressbar(width1: 177, hight1: 17 , percent: 77)
                        Text("\(Int(percent)) %")
                            .font(.system(size: 15))
                            .fontWeight(.regular)
                            .foregroundColor(.black)
                        
                    }.padding(.trailing)
                    
                }
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.984, green: 0.984, blue: 0.984)/*@END_MENU_TOKEN@*/)}
        }
    }
}

struct groupchallange2_Previews: PreviewProvider {
    static var previews: some View {
        groupchallange2()
    }
}
