//
//  individual challenge.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 13/05/1444 AH.
//

import SwiftUI
import HealthKit

struct individual_challenge: View {
    @State var spotfiyView = false
    @State var selectedSide: SideOfTheForce = .indivisual
    var body: some View {
        VStack{
            ScrollView(.vertical, showsIndicators: false) {
                
                
                
                VStack(spacing:25){
                    Text("""
                     Welcome,
                     Mohammed 👋
                     """)
                    .fontWeight(.semibold)
                    .padding(.leading,-100)
                    .padding(.top,30)
                    // .frame(width: 240, height: 50)
                    .font(.system(size: 28))
                    
                    Picker("Choose ", selection: $selectedSide){
                        ForEach(SideOfTheForce.allCases , id: \.self){
                            Text($0.rawValue)
                        }
                        
                    }.pickerStyle(SegmentedPickerStyle())
                        .background(Color("Color"))
                        .cornerRadius(20)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.white, lineWidth:0)
                            
                        )
                        .padding()
                    
                    
                    allViews(selectedSide: selectedSide)
                }
                
                
                
                    ScrollView(.horizontal, showsIndicators: false)  {
                        
                        HStack(spacing: -20) {
                            
                            Button(action: {
                                withAnimation{
                                    spotfiyView.toggle()
                                }
                            })
                            {
                                VStack{ Image("spotify1")
                                        .resizable()
                                        .cornerRadius(10)
                                    // .border(.black)
                                    Divider()
                                    Text("Spotify")
                                        .font(Font.custom("SF Compact", size: 15))
                                        .foregroundColor(Color ("Color"))
                                        .fontWeight(.semibold)
                                    Text(" Premium 30 Days")
                                        .font(Font.custom("SF Compact", size: 15))
                                        .foregroundColor(.black)
                                        .fontWeight(.semibold)
                                        .padding(.bottom,5)
                                }
                            }
                            .frame(width: 170, height: 190)
                            .background(Color.white)
                            .cornerRadius(10)
                            .overlay(RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.2))
                            .shadow(radius: 3)
                            .padding()
                            //  Spacer()
                            
                            VStack{
                                Image("play")
                                    .resizable()
                                    .cornerRadius(10)
                                Divider()
                                VStack(){
                                    Text("Playstation")
                                        .font(Font.custom("SF Compact", size: 15))
                                        .foregroundColor(Color ("Color"))
                                        .fontWeight(.semibold)
                                    Text("Gift Card 5$")
                                        .font(Font.custom("SF Compact", size: 15))
                                        .foregroundColor(.black)
                                        .fontWeight(.semibold)
                                        .padding(.bottom,5)
                                }
                            }
                            .frame(width: 170, height: 190)
                            .background(Color.white)
                            .cornerRadius(10)
                            .overlay(RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.2))
                            .shadow(radius: 3)
                            .padding()
                            //  Spacer()
                            
                            VStack{
                                Image("xbox1")
                                    .resizable()
                                    .cornerRadius(10)
                                Divider()
                                VStack(){
                                    Text("Xbox")
                                        .font(Font.custom("SF Compact", size: 15))
                                        .foregroundColor(Color ("Color"))
                                        .fontWeight(.semibold)
                                    Text("Gift Card 5$")
                                        .font(Font.custom("SF Compact", size: 15))
                                        .foregroundColor(.black)
                                        .fontWeight(.semibold)
                                        .padding(.bottom,5)
                                }
                            }
                            .frame(width:170, height: 190)
                            .background(Color.white)
                            .cornerRadius(10)
                            .overlay(RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.2))
                            .shadow(radius: 3)
                            .padding()
                        }
                        Spacer()
                       
                            .padding(.top,90)
                        
                    }}
            }
        
    }}
struct individual_challenge_Previews: PreviewProvider {
    static var previews: some View {
        individual_challenge()
    }
}


enum SideOfTheForce: String, CaseIterable{
    case indivisual = "Indivisual"
    case group = "Group"
    
}

struct allViews: View {
    var selectedSide: SideOfTheForce
    var body: some View{
        switch selectedSide {
        case .indivisual:
            indivisual()
        case .group:
            group()
        }
    }
}

struct group : View{
    @State var steps1: [Step] = [Step]()
    @State var  steps1_left = """
3000
Steps left
"""
    var body: some View{
        
        Text(")")
    }}
        
struct indivisual: View {
    private var healthStore: Healthstore?
    @State var steps: [Step] = [Step]()
    
        
//        var greetings = """
//Welcome,
//Mohammed 👋
//"""
        @State var  steps_left = """
   3000
Steps left
"""
        @State var  press = false
        @State var progress : Double = 0.2
        
        init(){ healthStore = Healthstore()
        }
    var body : some View {
//        func updateUIFromStatistics(_ statisticsCollection: HKStatisticsCollection) {
//
//            let startDate = Calendar.current.date(byAdding: .day, value: 3, to: Date())!
//            let endDate = Date()
//
//            statisticsCollection.enumerateStatistics(from: startDate, to: endDate) { (statistics, stop) in
//
//                let count = statistics.sumQuantity()?.doubleValue(for: .count())
//
//                let step = Step(count: Int(count ?? 0), date: statistics.startDate)
//                steps.append(step)
//
//            }
//        }
        
//        Text(greetings)
//                .fontWeight(.semibold)
//                .padding(.leading,-150)
//                .frame(width: 257.0, height: 68.0)
//                .font(.system(size: 28))
            
            Text("10000")
                .offset(x:0 , y:200)
                .font(.system(size: 15))
                .fontWeight(.semibold)
        
        
        ZStack{
            Circle()
                .offset(x:100 , y:180)
            
                .size(width: 194, height: 195)
            
            
            
            
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
            
         //   (Double(steps.count))/100)
            
            Circle()
                .offset(x:-130 , y:2)
                .trim(from: 0.00, to: 1.00)
                .stroke(style: StrokeStyle(lineWidth: 4.0, lineCap: .round, lineJoin: .round))
                .frame(width: 231, height: 215)
                .rotationEffect(Angle(degrees: -90))
            /*  if (steps.count==10000){
             
             
             
             } */
            
            
                .onAppear(perform: {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2 ){
                        
                        
                        
                    } })
            
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
            
            
             Text("\(steps.count)")
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                .padding(.top,250)
            
                .fontWeight(.semibold)
                .font(.system(size: 35))
            Circle()
                .size(width: 56, height: 53)
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                .offset(x:235 , y:300)
            Text(steps_left)
                .fontWeight(.semibold)
                .font(.system(size: 9))
                .foregroundColor(.white)
                .offset(x:67 , y:180)
            
        }
        .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
        Text("1/3")
            .offset(x:0 , y:70)
            .font(.system(size: 15))
            .fontWeight(.semibold)
        
        /* Text("Keep up the good work!")
         .offset(x:0 , y:-70)
         .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
         .font(.system(size: 28))
         .fontWeight(.semibold) */
        
        
   }
//            .onAppear {
//        if let healthStore = healthStore {
//            healthStore.requestAuthorization { success in
//                if success {
//                    healthStore.calculateSteps { statisticsCollection in
//                        if let statisticsCollection = statisticsCollection {
//                            // update the UI
//                            updateUIFromStatistics(statisticsCollection)
//                        }
//                    }
//                }
//            }
//        }
//    }
    }
