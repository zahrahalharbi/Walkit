//
//  individual challenge.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 13/05/1444 AH.
//

import SwiftUI
import HealthKit

struct individual_challenge: View {
    private var healthStore: Healthstore?
    @State private var steps: [Step] = [Step]()
   
    
    var greetings = """
Welcome,
Mohammed 👋
"""
   @State var  steps_left = """
   3000
Steps left
"""
    @State var  press = false
    @State private var progress : Double = 0.2
    init() {
        healthStore = Healthstore()
    }
    private func updateUIFromStatistics(_ statisticsCollection: HKStatisticsCollection) {
        
        let startDate = Calendar.current.date(byAdding: .day, value: 3, to: Date())!
        let endDate = Date()
        
        statisticsCollection.enumerateStatistics(from: startDate, to: endDate) { (statistics, stop) in
            
            let count = statistics.sumQuantity()?.doubleValue(for: .count())
            
            let step = Step(count: Int(count ?? 0), date: statistics.startDate)
            steps.append(step)
            
        }
        
        
      
    }
    var body: some View {
        
        VStack{
            Text(greetings)
                .fontWeight(.semibold)
                .padding(.leading,-150)
                .frame(width: 257.0, height: 68.0)
                .font(.system(size: 28))
            
            HStack{
                Button {
                    press.toggle()
                } label: {
                    Text("Individual ")
                        .foregroundColor(.white)
                        .frame(width: 166.0, height: 38.0)
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                        .cornerRadius(8)
                        .font(.system(size: 15))
                    
                    
                }
                Button {
                    press.toggle()
                } label: {
                    Text("Group")
                        .foregroundColor(.black)
                        .frame(width: 166.0, height: 38.0)
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
                        .cornerRadius(8)
                        .font(.system(size: 15))
                    
                }
                
            }
            
            Text("10000")
                .offset(x:0 , y:90)
                .font(.system(size: 15))
                .fontWeight(.semibold)
            
            
            ZStack{
                Circle()
                    .offset(x:100 , y:100)
                
                    .size(width: 194, height: 195)
                    
                
                
                
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
               
             /*   while steps.count <= 10000 {
                    progresscircle  += 0.5
                }*/
              
                Circle()
                    .offset(x:77 , y:2)
                    .trim(from: 0.0, to: (Double(steps.count))/10)
                    .stroke(style: StrokeStyle(lineWidth: 4.0, lineCap: .round, lineJoin: .round))
                    .frame(width: 231, height: 227)
                      .rotationEffect(Angle(degrees: -90))
                      
                 .onAppear(perform: {
                     DispatchQueue.main.asyncAfter(deadline: .now() + 2 ){
                         
                       
                         
                     } })
                
                   .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                
                  
                        Text("\(steps.count)")
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                    .padding(.bottom,160)
                  
                    .fontWeight(.semibold)
                    .font(.system(size: 35))
                Circle()
                    .size(width: 56, height: 53)
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                    .offset(x:235 , y:270)
                Text(steps_left)
                    
                    .fontWeight(.semibold)
                  
                    .font(.system(size: 9))
                    .foregroundColor(.white)
                    .offset(x:67 , y:20)
                    
           
               
            }
            .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
            Text("1/3")
                .offset(x:0 , y:-230)
                .font(.system(size: 15))
                .fontWeight(.semibold)
            
            Text("Keep up the good work!")
                .offset(x:0 , y:-70)
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                .font(.system(size: 28))
                .fontWeight(.semibold)
                
            
        }
        .onAppear {
            if let healthStore = healthStore {
                healthStore.requestAuthorization { success in
                    if success {
                        healthStore.calculateSteps { statisticsCollection in
                            if let statisticsCollection = statisticsCollection {
                                // update the UI
                                updateUIFromStatistics(statisticsCollection)
                            }
                        }
                    }
                }
            }
        }
    }
}
struct individual_challenge_Previews: PreviewProvider {
    static var previews: some View {
        individual_challenge()
    }
}
