//
//  progress bar.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 14/05/1444 AH.
//

import SwiftUI

struct progress_bar: View {
    var body: some View {
        
        ZStack{
            Circle()
                .offset(x:100 , y:100)
            
                .size(width: 194, height: 195)
                
            
            
            
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
          
              
          
        }
    }
}

struct progress_bar_Previews: PreviewProvider {
    static var previews: some View {
        progress_bar()
    }
}
