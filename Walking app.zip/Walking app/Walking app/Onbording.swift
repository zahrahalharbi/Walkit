//
//  Onbording.swift
//  Walking app
//
//  Created by Zahrah. on 06/12/2022.
//

import Foundation
import SwiftUI


struct Onboarding : View {
    @State private var pageIndex = 0
    private let pages: [Page] = Page.samplePages
    private let dotAppearance = UIPageControl.appearance()
    
    var body: some View {
        
        TabView(selection: $pageIndex) {
            ForEach(pages) { page in
                VStack {
                    PageView(page: page)
                    
                    if page == pages.last {
                        Button("Get Started!", action: goToZero)
                            .cornerRadius(1.5)
                            .buttonStyle(.bordered)
                            .foregroundColor(.white)
                            .background(Color.red)
                    }
                    Spacer()
                }
                .tag(page.tag)
            }
        }
        .ignoresSafeArea()
        .animation(.easeInOut, value: pageIndex)// 2
        .indexViewStyle(.page(backgroundDisplayMode: .interactive))
        .tabViewStyle(PageTabViewStyle())
        
        .onAppear {
            dotAppearance.currentPageIndicatorTintColor = .black
            dotAppearance.pageIndicatorTintColor = .gray
        }
    }
    func incrementPage() {
        pageIndex += 1
    }
    
    func goToZero() {
        pageIndex = 0
    }
}
struct Onboarding_Previews: PreviewProvider {
    static var previews: some View {
        Onboarding()
    }
}
