//
//  GroupChallange.swift
//  Walking app
//
//  Created by Rahaf Alhejaili on 14/05/1444 AH.
//

import SwiftUI

struct GroupChallange: View {
    var greetings = """
Welcome,
Mohammed 👋
"""
   @State var  steps_left = """
   3000
Steps left
"""
    @State var  press = false
    @State private var progress : Double = 0.75
    var body: some View {
        VStack(spacing: 30){
            HStack{
                Text(greetings)
                    .fontWeight(.semibold)
                    .padding(.trailing)
                    .frame(width: 257.0, height: 68.0)
                    .font(.system(size: 28))
                Spacer()
            }
            HStack{
                Button {
                    press.toggle()
                } label: {
                    Text("Individual ")
                        .foregroundColor(.black)
                        .frame(width: 166.0, height: 38.0)
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
                        .cornerRadius(8)
                        .font(.system(size: 15))
                    
                    
                }
                Button {
                    press.toggle()
                } label: {
                    Text("Group")
                        .foregroundColor(.white)
                        .frame(width: 166.0, height: 38.0)
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                        .cornerRadius(8)
                        .font(.system(size: 15))
                    
                }
                
            }
            
            
            Text("1000")
                .padding(.all)
                
                .font(.system(size: 15))
                .fontWeight(.semibold)
            
            
            HStack(alignment: .center) {
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                
                ZStack(alignment: .center){
                    Spacer()
                        
                    Circle()
                    
                        .trim(from: 0.0, to: self.progress)
                        .stroke(style: StrokeStyle(lineWidth: 4.0, lineCap: .round, lineJoin: .round))
                    
                        .size(width: 231, height: 227)
                    
                        .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                        .padding(.leading)
                    HStack(alignment: .center) {
                        Spacer()
                        Spacer()
                        Circle()
                           
                      
                        
                        
                            .size(width: 194, height: 195)
                            .padding(.all)
                          
                        
                        
                            .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
                        
                        /* Text("7000 Steps")
                         
                         
                         .fontWeight(.semibold)
                         .font(.system(size: 35))
                         Circle()
                         
                         
                         .size(width: 194, height: 195)
                         
                         
                         
                         .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.85, green: 0.835, blue: 0.835)/*@END_MENU_TOKEN@*/)
                         
                         
                         
                         Circle()
                         .size(width: 56, height: 53)
                         .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                         //  .offset(x:235 , y:270)
                         Text(steps_left)
                         
                         .fontWeight(.semibold)
                         
                         .font(.system(size: 9))
                         .foregroundColor(.white)
                         */
                        
                        //.onappear {}
                        
                        
                    }}
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
              
                    .padding(.all)
                
            }
            
            Text("1/3")
               
                .font(.system(size: 15))
                .fontWeight(.semibold)
                .padding([.top, .leading, .bottom])
            
            Text("Keep up the good work!")
              
                .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                .font(.system(size: 28))
                .fontWeight(.semibold)
                
            
        }
    }
}

struct GroupChallange_Previews: PreviewProvider {
    static var previews: some View {
        GroupChallange()
    }
}
