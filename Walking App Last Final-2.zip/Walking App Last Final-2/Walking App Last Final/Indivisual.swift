//
//  Indivisual.swift
//  Walking App Last Final
//
//  Created by Zahrah. on 19/12/2022.
//

import SwiftUI
import HealthKit
import Foundation

struct Indivisual: View {
    @State var spotifyView = false
    @State var IsShow = false
    private var healthStore: Healthstore?
    @State var steps: [Step] = [Step]()
    var totalSteps = 10000
    /*  @State var steps_left = """
     3000
     Steps left
     """*/
    @State var Press = false
    @State var Progress: Double = 0.2
    init (){ healthStore = Healthstore()}
    private func updateUIFromStatistics(_ statisticsCollection: HKStatisticsCollection) {
        
        let startDate = Calendar.current.date(byAdding: .day, value: 3, to: Date())!
        let endDate = Date()
        
        statisticsCollection.enumerateStatistics(from: startDate, to: endDate) { (statistics, stop) in
            
            let count = statistics.sumQuantity()?.doubleValue(for: .count())
            
            let step = Step(count: Int(count ?? 0), date: statistics.startDate)
            steps.append(step)
            
        }
    }
    var body: some View {
        ZStack{
            HStack{ Text("""
Welcome
Mohammed👋
""")
            .font(.title)
            .foregroundColor(Color.black)
            .fontWeight(.bold)
            .font(Font.custom("SF Compact", size: 26))
            .padding(.top,-210)
            .padding(.trailing,150)
                
            
                
                Image(systemName: "trophy")
                    .fontWeight(.bold)
                    .padding(.top,-200)
                     .foregroundColor(Color("Color"))
                     .onTapGesture {
                         IsShow.toggle()
                     }
                
                
                
//                Button(action: ){
//                    IsShow.toggle()
//                }{
//                    Image(systemName: "trophy")
//                        .fontWeight(.bold)
//                            .padding(.top,-200)
//                            .foregroundColor(Color("Color"))
//                }
                   
                
            }
                Text ("Challenges ")
                    .foregroundColor(Color("Color"))
                    .font(Font.custom("SF Compact", size: 26))
                    .fontWeight(.semibold)
                    .padding(.top,-100)
                    .padding(.trailing,230)
                
                // ScrollView(.horizontal, showsIndicators: false){
                
                ForEach(category) { i in
                    VStack(spacing: 10){
                        HStack {
                            Text(i.title)
                                .font(.custom("SF Compact", size: i.size))
                                .fontWeight(.bold)
                            
                            Spacer()
                        }
                        
                        LocationView(row: i.gridItem, cardHeight: i.cardHeight).presentationDetents([.medium, .fraction(0.50)])
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 30)
                }
                
                ZStack{
                    Text("\(totalSteps)")
                        .padding(.top,-100)
                        .font(.system(size: 15))
                        .fontWeight(.semibold)
                    
                    Circle()
                        .offset(x:100 , y:260)
                    
                        .size(width: 194, height: 195)
                        .foregroundColor(Color(red: 0.85 , green: 0.835 , blue: 0.835))
                    Circle()
                        .offset(x:-27 , y:0)
                        .trim(from: 0.00, to: Double(steps.count)/1000)
                        .stroke(style: StrokeStyle(lineWidth: 4.0, lineCap: .round, lineJoin: .round))
                        .frame(width: 231, height: 215)
                        .rotationEffect(Angle(degrees: -90))
                    
                        .onAppear(perform: {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2 ){
                                
                            } })
                    
                        .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                    
                    
                    Text("\(steps.count)")
                        .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                        .padding(.top,50)
                    
                        .fontWeight(.semibold)
                        .font(.system(size: 35))
                    Circle()
                        .size(width: 60, height: 53)
                        .foregroundColor(Color(red: 0.78, green: 0.174, blue: 0.172))
                        .offset(x:70 , y:400)
                    Text("\(totalSteps - steps.count )")
                        .fontWeight(.semibold)
                        .font(.system(size: 9))
                        .foregroundColor(.white)
                        .offset(x:-97 , y:97)
                    
                    
                        .foregroundColor(/*@START_MENU_TOKEN@*/Color(red: 0.78, green: 0.174, blue: 0.172)/*@END_MENU_TOKEN@*/)
                    Text("1/3")
                        .offset(x:0 , y:150)
                        .font(.system(size: 15))
                        .fontWeight(.semibold)
                    
                    Text("Keep up the good work!")
                        .offset(x:0 , y:280)
                        .foregroundColor(Color(("Color")))
                        .font(.system(size: 28))
                        .fontWeight(.semibold)
                    
                    Button(action: share1){
                        Text("invite Friends ")}
                    .background(Color("Color"))
                    .foregroundColor(Color.white)
                    .buttonStyle(.bordered)
                    .cornerRadius(8)
                    .offset(x:3,y:190)
                }
                
                
                .padding(.top,400)
                
                .onAppear {
                    if let healthStore = healthStore {
                        healthStore.requestAuthorization { success in
                            if success {
                                healthStore.calculateSteps { statisticsCollection in
                                    if let statisticsCollection = statisticsCollection {
                                        // update the UI
                                        updateUIFromStatistics(statisticsCollection)
                                    }
                                }
                            }
                        }
                    }
                }
                
            }
            .padding(.top,-300)
            
            .sheet(isPresented: $IsShow){
                trophy1()
                
            }
            
        }
    }
    
    struct Indivisual_Previews: PreviewProvider {
        static var previews: some View {
            Indivisual()
        }
    }
    
    
    struct Category: Identifiable {
        var id = UUID()
        var title: String
        var size: CGFloat
        var gridItem: [GridItem]
        var cardHeight: CGFloat
    }
    
    var category = [
        Category(title: "", size: 26, gridItem: Array(repeating: GridItem(.fixed(125), spacing: 10), count: 1), cardHeight: 105)
    ]
    
    func share1() {
        guard let urlShare = URL(string: "https://developer.apple.com") else { return }
        let activityVC = UIActivityViewController(activityItems: [urlShare], applicationActivities: nil)
        UIApplication.shared.windows.first?.rootViewController?.present(activityVC, animated: true, completion: nil)
    }
    
//    struct trophy: View {
//
//
//            ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)){
//                VStack(spacing: 25){
//                    Text("Congrats!")
//                        .font(.custom("SF Compact", fixedSize: 28))
//                        .fontWeight(.ultraLight)
//                    Image(systemName: "trophy.fill")
//                        .foregroundColor(Color("Color2"))
//                        .font(.custom("SF pro", fixedSize: 70))
//                        .scaledToFill()
//
//                    Text("Total group Challeng: 7")
//                        .font(Font.custom("SF Compact", size: 15))
//                        .foregroundColor(Color("Color1"))
//
//                    Text("Total individua Challeng: 9")
//                        .font(Font.custom("SF Compact", size: 15))
//                        .foregroundColor(Color("Color1"))
//
//                }
//                .padding(.vertical,25)
//                .padding(.horizontal,30)
//                .background(.white)
//                .cornerRadius(25)
//
//            }
//            .frame(maxWidth: .infinity, maxHeight: .infinity)
//            .background(Color.primary.opacity(0.35))
//        }
//    }
//
    

struct trophy1: View {
    
    var body: some View {
        VStack(spacing: 25){
            Text("Congrats!")
                .font(.custom("SF Compact", fixedSize: 28))
                .fontWeight(.ultraLight)
            Image(systemName: "trophy.fill")
                .foregroundColor(Color("Color2"))
                .font(.custom("SF pro", fixedSize: 70))
                .scaledToFill()
            
            Text("Total group Challeng: 7")
                .font(Font.custom("SF Compact", size: 15))
                .foregroundColor(Color("Color1"))
            
            Text("Total individua Challeng: 9")
                .font(Font.custom("SF Compact", size: 15))
                .foregroundColor(Color("Color1"))
            
        }
    }
}
